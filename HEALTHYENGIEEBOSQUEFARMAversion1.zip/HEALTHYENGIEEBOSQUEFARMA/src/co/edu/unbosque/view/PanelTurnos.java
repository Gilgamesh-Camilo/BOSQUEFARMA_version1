package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelTurnos extends JPanel {
    private JTextField txtDocumento;
    private JButton butGenerarTurno;
    private JTextArea areaTurnos;
    private JScrollPane scrollTurnos;
    private JButton butAtenderTurno;
    public static final String COMANDO_GENERAR_TURNO = "GENERAR_TURNO";
    public static final String COMANDO_ATENDER_TURNO = "ATENDER_TURNO";

    public PanelTurnos() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel panelSuperior = new JPanel(new GridLayout(2, 2, 10, 10));
        panelSuperior.add(new JLabel("Documento del paciente:"));
        txtDocumento = new JTextField();
        panelSuperior.add(txtDocumento);

        butGenerarTurno = new JButton("Generar Turno");
        butGenerarTurno.setActionCommand(COMANDO_GENERAR_TURNO);
        butAtenderTurno = new JButton("Atender Siguiente Turno");
        butAtenderTurno.setActionCommand(COMANDO_ATENDER_TURNO);

        panelSuperior.add(butGenerarTurno);
        panelSuperior.add(butAtenderTurno);
        add(panelSuperior, BorderLayout.NORTH);

        areaTurnos = new JTextArea();
        areaTurnos.setEditable(false);
        scrollTurnos = new JScrollPane(areaTurnos);
        add(scrollTurnos, BorderLayout.CENTER);
    }

    public void configurarBotones(ActionListener listener) {
        butGenerarTurno.addActionListener(listener);
        butAtenderTurno.addActionListener(listener);
    }

    // Getters
    public JTextField getTxtDocumento() { return txtDocumento; }
    public JTextArea getAreaTurnos() { return areaTurnos; }
}
