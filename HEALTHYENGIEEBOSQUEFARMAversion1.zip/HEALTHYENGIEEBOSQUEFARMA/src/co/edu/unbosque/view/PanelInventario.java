package co.edu.unbosque.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelInventario extends JPanel {
	
    private JTextField txtCodigo;
    private JTextField txtNombre;
    private JTextField txtCantidad;
    private JTextField txtPrecio;
    private JButton butAgregar;
    private JTable tablaInventario;
    private DefaultTableModel modeloTabla;
    public static final String COMANDO_AGREGAR = "AGREGAR_MEDICAMENTO";

    public PanelInventario() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JPanel panelDatos = new JPanel(new GridLayout(5, 2, 10, 10));
        panelDatos.add(new JLabel("Código:"));
        txtCodigo = new JTextField();
        panelDatos.add(txtCodigo);
        panelDatos.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panelDatos.add(txtNombre);
        panelDatos.add(new JLabel("Cantidad:"));
        txtCantidad = new JTextField();
        panelDatos.add(txtCantidad);
        panelDatos.add(new JLabel("Precio:"));
        txtPrecio = new JTextField();
        panelDatos.add(txtPrecio);

        butAgregar = new JButton("Agregar Medicamento");
        butAgregar.setActionCommand(COMANDO_AGREGAR);
        panelDatos.add(new JLabel(""));
        panelDatos.add(butAgregar);

        add(panelDatos, BorderLayout.NORTH);

        String[] columnas = {"Código", "Nombre", "Cantidad", "Precio"};
        modeloTabla = new DefaultTableModel(columnas, 0);
        tablaInventario = new JTable(modeloTabla);
        JScrollPane scrollTabla = new JScrollPane(tablaInventario);
        add(scrollTabla, BorderLayout.CENTER);
    }

    public void configurarBotones(ActionListener listener) {
        butAgregar.addActionListener(listener);
    }

    public void actualizarTabla(String inventarioActual) {
        modeloTabla.setRowCount(0);
        String[] filas = inventarioActual.split("\n");
        for (String fila : filas) {
            String[] datos = fila.split("\\|");
            modeloTabla.addRow(datos);
        }
    }

    // Getters
    public JTextField getTxtCodigo() { return txtCodigo; }
    public JTextField getTxtNombre() { return txtNombre; }
    public JTextField getTxtCantidad() { return txtCantidad; }
    public JTextField getTxtPrecio() { return txtPrecio; }
}