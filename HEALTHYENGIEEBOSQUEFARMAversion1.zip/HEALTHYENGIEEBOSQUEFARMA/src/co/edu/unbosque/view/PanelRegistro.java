package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelRegistro extends JPanel {
    private JTextField txtNombre;
    private JTextField txtCedula;
    private JPasswordField txtPassword;
    private JTextField txtCorreo;
    private JButton butRegistrar;
    public static final String COMANDO_REGISTRAR = "REGISTRAR";

    public PanelRegistro() {
        setLayout(new GridLayout(5, 2, 10, 10));
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        add(txtNombre);

        add(new JLabel("Cédula:"));
        txtCedula = new JTextField();
        add(txtCedula);

        add(new JLabel("Contraseña:"));
        txtPassword = new JPasswordField();
        add(txtPassword);

        add(new JLabel("Correo:"));
        txtCorreo = new JTextField();
        add(txtCorreo);

        butRegistrar = new JButton("Registrar");
        butRegistrar.setActionCommand(COMANDO_REGISTRAR);
        add(new JLabel(""));
        add(butRegistrar);
    }

    public void configurarBotones(ActionListener listener) {
        butRegistrar.addActionListener(listener);
    }

    // Getters
    public JTextField getTxtNombre() { return txtNombre; }
    public JTextField getTxtCedula() { return txtCedula; }
    public JPasswordField getTxtPassword() { return txtPassword; }
    public JTextField getTxtCorreo() { return txtCorreo; }
}