package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;

import co.edu.unbosque.controller.Controller;

public class View extends JFrame {
    private JLabel imagen1;
    private JPanel contentPane;
    private CardLayout cardLayout;

    private PanelMenuPrincipal panelMenuPrincipal;
    private PanelLogin panelLogin;
    private PanelRegistro panelRegistro;
    private PanelPrincipal panelPrincipal;
    private PanelTurnos panelTurnos;
    private PanelInventario panelInventario;

    public View(Controller control) {
        // Configuraciones de la ventana
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setTitle("BosqueFarma - Sistema de Farmacia v1.0");
        setLocationRelativeTo(null);
        setResizable(true);

        ImageIcon nuevoIcono = new ImageIcon("src/co/edu/unbosque/view/ICON,BOSQUEFARMA1.png");
        setIconImage(nuevoIcono.getImage());

        // Intentar cargar la imagen de fondo y redimensionarla
        ImageIcon fondoIcono = new ImageIcon("src/co/edu/unbosque/view/FONDO.png");
        Image imagen = fondoIcono.getImage().getScaledInstance(100, 100, Image.SCALE_AREA_AVERAGING); // Puedes ajustar estos números
        imagen1 = new JLabel(new ImageIcon(imagen));

        imagen1.setLayout(new BorderLayout());
        imagen1.setBorder(null);

        // Inicializar el CardLayout y contentPane
        cardLayout = new CardLayout();
        contentPane = new JPanel(cardLayout);

        // Inicializar todos los paneles
        panelMenuPrincipal = new PanelMenuPrincipal(control);
        contentPane.add(panelMenuPrincipal, "MENU_PRINCIPAL");

        panelLogin = new PanelLogin(control, this);
        contentPane.add(panelLogin, "LOGIN");

        panelRegistro = new PanelRegistro();
        contentPane.add(panelRegistro, "REGISTRO");

        panelPrincipal = new PanelPrincipal();
        contentPane.add(panelPrincipal, "PRINCIPAL");

        panelTurnos = new PanelTurnos();
        contentPane.add(panelTurnos, "TURNOS");

        panelInventario = new PanelInventario();
        contentPane.add(panelInventario, "INVENTARIO");

        imagen1.add(contentPane, BorderLayout.CENTER);
        setContentPane(imagen1);
        setVisible(true);

        mostrarPanelMenuPrincipal();
    }

    public void mostrarPanelMenuPrincipal() {
        cardLayout.show(contentPane, "MENU_PRINCIPAL");
    }

    public void mostrarPanelLogin() {
        cardLayout.show(contentPane, "LOGIN");
    }

    public void mostrarPanelRegistro() {
        cardLayout.show(contentPane, "REGISTRO");
    }

    public void mostrarPanelPrincipal(boolean esFuncionario) {
        panelPrincipal.actualizarVista(esFuncionario);
        cardLayout.show(contentPane, "PRINCIPAL");
    }

    public void mostrarPanelTurnos() {
        cardLayout.show(contentPane, "TURNOS");
    }

    public void mostrarPanelInventario() {
        cardLayout.show(contentPane, "INVENTARIO");
    }

    public void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
    }

    public void volverAlMenuPrincipal() {
        mostrarPanelMenuPrincipal();
    }

    public void mostrarEstadisticas(String estadisticas) {
        JTextArea textArea = new JTextArea(estadisticas);
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(400, 300));
        JOptionPane.showMessageDialog(this, scrollPane, "Estadísticas", JOptionPane.INFORMATION_MESSAGE);
    }

    // Getters para los paneles
    public PanelMenuPrincipal getPanelMenuPrincipal() { return panelMenuPrincipal; }
    public PanelLogin getPanelLogin() { return panelLogin; }
    public PanelRegistro getPanelRegistro() { return panelRegistro; }
    public PanelPrincipal getPanelPrincipal() { return panelPrincipal; }
    public PanelTurnos getPanelTurnos() { return panelTurnos; }
    public PanelInventario getPanelInventario() { return panelInventario; }
}
