package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

import co.edu.unbosque.controller.Controller;

public class PanelLogin extends JPanel {
	
    private JTextField txtCedula;
    private JPasswordField txtPassword;
    private JButton butLogin;
    private JButton butRegresar;

    public PanelLogin(Controller control, View view) {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        JLabel lblCedula = new JLabel("Cédula:");
        txtCedula = new JTextField(15);
        JLabel lblPassword = new JLabel("Contraseña:");
        txtPassword = new JPasswordField(15);
        butLogin = new JButton("Iniciar Sesión");
        butRegresar = new JButton("Regresar");

        gbc.gridx = 0; gbc.gridy = 0;
        add(lblCedula, gbc);
        gbc.gridx = 1;
        add(txtCedula, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        add(lblPassword, gbc);
        gbc.gridx = 1;
        add(txtPassword, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 2;
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        buttonPanel.add(butLogin);
        buttonPanel.add(butRegresar);
        add(buttonPanel, gbc);

        butLogin.addActionListener(control);
        butLogin.setActionCommand("LOGIN");
        butRegresar.addActionListener(e -> view.volverAlMenuPrincipal());
    }

    public void configurarBotones(ActionListener listener) {
        butLogin.addActionListener(listener);
    }

    // Getters
    public JTextField getTxtCedula() { return txtCedula; }
    public JPasswordField getTxtPassword() { return txtPassword; }
}