package co.edu.unbosque.controller;

import co.edu.unbosque.model.ClaseX;
import co.edu.unbosque.view.View;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controller implements ActionListener {
    private ClaseX modelo;
    private View vista;
    private String usuarioActual;
    private boolean esFuncionario;

    public Controller() {
        modelo = new ClaseX();
        vista = new View(this);
        vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent evento) {
        String comando = evento.getActionCommand();
        String resultado = "";

        try {
            switch (comando) {
                case "INGRESAR_USUARIO":
                    esFuncionario = false;
                    vista.mostrarPanelLogin();
                    break;

                case "INGRESAR_FUNCIONARIO":
                    esFuncionario = true;
                    vista.mostrarPanelLogin();
                    break;

                case "REGISTRAR_USUARIO":
                    esFuncionario = false;
                    vista.mostrarPanelRegistro();
                    break;

                case "REGISTRAR_FUNCIONARIO":
                    esFuncionario = true;
                    vista.mostrarPanelRegistro();
                    break;

                case "LOGIN":
                    resultado = modelo.procesarOperacion("LOGIN", 
                        vista.getPanelLogin().getTxtCedula().getText(),
                        new String(vista.getPanelLogin().getTxtPassword().getPassword()));
                    if (resultado.startsWith("Login exitoso")) {
                        usuarioActual = vista.getPanelLogin().getTxtCedula().getText();
                        vista.mostrarPanelPrincipal(esFuncionario);
                        vista.mostrarMensaje("Bienvenido al sistema");
                    } else {
                        vista.mostrarMensaje(resultado);
                    }
                    break;

                case "REGISTRAR":
                    resultado = modelo.procesarOperacion("REGISTRO_" + (esFuncionario ? "FUNCIONARIO" : "USUARIO"),
                        vista.getPanelRegistro().getTxtNombre().getText(),
                        vista.getPanelRegistro().getTxtCedula().getText(),
                        new String(vista.getPanelRegistro().getTxtPassword().getPassword()),
                        vista.getPanelRegistro().getTxtCorreo().getText());
                    if (resultado.contains("exitoso")) {
                        vista.mostrarMensaje("Registro exitoso");
                        vista.mostrarPanelMenuPrincipal();
                    } else {
                        vista.mostrarMensaje(resultado);
                    }
                    break;

                case "GENERAR_TURNO":
                    resultado = modelo.procesarOperacion("GENERAR_TURNO",
                        vista.getPanelTurnos().getTxtDocumento().getText());
                    actualizarTurnos();
                    vista.mostrarMensaje(resultado);
                    break;

                case "ATENDER_TURNO":
                    if (esFuncionario) {
                        resultado = modelo.procesarOperacion("ATENDER_TURNO", usuarioActual);
                        actualizarTurnos();
                        vista.mostrarMensaje(resultado);
                    }
                    break;

                case "AGREGAR_MEDICAMENTO":
                    if (esFuncionario) {
                        resultado = modelo.procesarOperacion("AGREGAR_MEDICAMENTO",
                            vista.getPanelInventario().getTxtCodigo().getText(),
                            vista.getPanelInventario().getTxtNombre().getText(),
                            vista.getPanelInventario().getTxtCantidad().getText(),
                            vista.getPanelInventario().getTxtPrecio().getText());
                        actualizarInventario();
                        vista.mostrarMensaje(resultado);
                    }
                    break;

                case "MOSTRAR_TURNOS":
                    vista.mostrarPanelTurnos();
                    actualizarTurnos();
                    break;

                case "MOSTRAR_INVENTARIO":
                    if (esFuncionario) {
                        vista.mostrarPanelInventario();
                        actualizarInventario();
                    }
                    break;

                case "VER_ESTADISTICAS":
                    if (esFuncionario) {
                        resultado = modelo.procesarOperacion("OBTENER_ESTADISTICAS");
                        vista.mostrarEstadisticas(resultado);
                    }
                    break;

                case "CERRAR_SESION":
                    usuarioActual = null;
                    esFuncionario = false;
                    vista.mostrarPanelMenuPrincipal();
                    break;
            }
        } catch (Exception e) {
            vista.mostrarMensaje("Error: " + e.getMessage());
        }
    }

    private void actualizarTurnos() {
        String turnosActuales = modelo.procesarOperacion("OBTENER_TURNOS");
        vista.getPanelTurnos().getAreaTurnos().setText(turnosActuales);
    }

    private void actualizarInventario() {
        String inventarioActual = modelo.procesarOperacion("OBTENER_INVENTARIO");
        vista.getPanelInventario().actualizarTabla(inventarioActual);
    }
}