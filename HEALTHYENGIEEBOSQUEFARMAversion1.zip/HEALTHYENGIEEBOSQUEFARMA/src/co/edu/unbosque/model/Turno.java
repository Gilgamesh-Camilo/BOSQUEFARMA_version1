package co.edu.unbosque.model;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Turno implements Serializable {
    private static final long serialVersionUID = 1L;
    private int numero;
    private String documentoPaciente;
    private LocalDateTime fechaGeneracion;
    private LocalDateTime fechaAtencion;
    private String estado;

    public Turno(int numero, String documentoPaciente) {
        this.numero = numero;
        this.documentoPaciente = documentoPaciente;
        this.fechaGeneracion = LocalDateTime.now();
        this.estado = "Por atender";
    }

    // Getters y setters
    public int getNumero() { return numero; }
    public String getDocumentoPaciente() { return documentoPaciente; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public void setFechaAtencion(LocalDateTime fechaAtencion) { this.fechaAtencion = fechaAtencion; }
}
