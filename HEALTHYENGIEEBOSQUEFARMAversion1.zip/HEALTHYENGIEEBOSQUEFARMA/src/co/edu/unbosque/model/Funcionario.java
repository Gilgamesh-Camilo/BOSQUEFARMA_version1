package co.edu.unbosque.model;

import java.io.Serializable;

public class Funcionario extends Usuario implements Serializable {
	
    private static final long serialVersionUID = 1L;
    
    public Funcionario(String nombre, String documento, String password, String correo) {
        super(nombre, documento, password, correo);
    }
}