package co.edu.unbosque.model;

import java.io.Serializable;
import java.time.LocalDateTime;

public class Usuario implements Serializable {
    private static final long serialVersionUID = 1L;
    protected String nombre;
    protected String documento;
    protected String password;
    protected String correo;

    public Usuario(String nombre, String documento, String password, String correo) {
        this.nombre = nombre;
        this.documento = documento;
        this.password = password;
        this.correo = correo;
    }
    // Getters y setters
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getDocumento() { return documento; }
    public void setDocumento(String documento) { this.documento = documento; }
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }
}
