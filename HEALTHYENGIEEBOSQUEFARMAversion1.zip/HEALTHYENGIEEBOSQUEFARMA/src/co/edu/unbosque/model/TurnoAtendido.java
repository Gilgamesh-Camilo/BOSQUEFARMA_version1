package co.edu.unbosque.model;

import java.io.Serializable;
import java.time.LocalDateTime;

public class TurnoAtendido implements Serializable {
    private static final long serialVersionUID = 1L;
    private int idTurno;
    private LocalDateTime fechaHora;
    private Funcionario funcionario;

    public TurnoAtendido(int idTurno, LocalDateTime fechaHora, Funcionario funcionario) {
        this.idTurno = idTurno;
        this.fechaHora = fechaHora;
        this.funcionario = funcionario;
    }

    public int getIdTurno() {
        return idTurno;
    }

    public void setIdTurno(int idTurno) {
        this.idTurno = idTurno;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(LocalDateTime localDateTime) {
        this.fechaHora = localDateTime;
    }

    public Funcionario getFuncionario() {
        return funcionario;
    }

    public void setFuncionario(Funcionario funcionario) {
        this.funcionario = funcionario;
    }

    @Override
    public String toString() {
        return "TurnoAtendido{" +
                "idTurno=" + idTurno +
                ", fechaHora='" + fechaHora + '\'' +
                ", funcionario=" + funcionario +
                '}';
    }

	public void setEstado(String string) {
		// TODO Auto-generated method stub
		
	}

	public String getNumero() {
		// TODO Auto-generated method stub
		return null;
	}
}