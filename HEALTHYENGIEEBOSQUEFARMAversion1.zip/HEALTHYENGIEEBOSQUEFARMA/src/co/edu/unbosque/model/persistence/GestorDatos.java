package co.edu.unbosque.model.persistence;

import java.io.*;
import java.util.*;
import co.edu.unbosque.model.*;

public class GestorDatos {
    private final String RUTA_BASE;
    private final String[] SUBCARPETAS = {
        "funcionarios", "usuarios", "turnos", 
        "turnosAtendidos", "inventario", "medicamentos"
    };

    public GestorDatos() {
        // Crear carpeta principal en el escritorio
        String userHome = System.getProperty("user.home");
        RUTA_BASE = userHome + File.separator + "Desktop" + File.separator + "bosquefarma" + File.separator;
        inicializarDirectorios();
    }

    private void inicializarDirectorios() {
        // Crear directorio principal
        File dirPrincipal = new File(RUTA_BASE);
        if (!dirPrincipal.exists()) {
            dirPrincipal.mkdirs();
        }

        // Crear subdirectorios
        for (String subcarpeta : SUBCARPETAS) {
            File subdir = new File(RUTA_BASE + subcarpeta);
            if (!subdir.exists()) {
                subdir.mkdirs();
            }
        }
    }

    private String getRutaArchivo(String tipo) {
        return RUTA_BASE + tipo + File.separator + tipo + ".dat";
    }

    public void guardarFuncionarios(ArrayList<Funcionario> funcionarios) {
        guardarObjeto(getRutaArchivo("funcionarios"), funcionarios);
    }

    public ArrayList<Funcionario> cargarFuncionarios() {
        ArrayList<Funcionario> resultado = (ArrayList<Funcionario>) cargarObjeto(getRutaArchivo("funcionarios"));
        return resultado != null ? resultado : new ArrayList<>();
    }

    public void guardarUsuarios(ArrayList<Usuario> usuarios) {
        guardarObjeto(getRutaArchivo("usuarios"), usuarios);
    }

    public ArrayList<Usuario> cargarUsuarios() {
        ArrayList<Usuario> resultado = (ArrayList<Usuario>) cargarObjeto(getRutaArchivo("usuarios"));
        return resultado != null ? resultado : new ArrayList<>();
    }

    public void guardarTurnos(ArrayList<Turno> turnos) {
        guardarObjeto(getRutaArchivo("turnos"), turnos);
    }

    public ArrayList<Turno> cargarTurnos() {
        ArrayList<Turno> resultado = (ArrayList<Turno>) cargarObjeto(getRutaArchivo("turnos"));
        return resultado != null ? resultado : new ArrayList<>();
    }

    public void guardarTurnosAtendidos(ArrayList<TurnoAtendido> turnosAtendidos) {
        guardarObjeto(getRutaArchivo("turnosAtendidos"), turnosAtendidos);
    }

    public ArrayList<TurnoAtendido> cargarTurnosAtendidos() {
        ArrayList<TurnoAtendido> resultado = (ArrayList<TurnoAtendido>) cargarObjeto(getRutaArchivo("turnosAtendidos"));
        return resultado != null ? resultado : new ArrayList<>();
    }

    public void guardarInventario(HashMap<String, Medicamento> inventario) {
        guardarObjeto(getRutaArchivo("inventario"), inventario);
    }

    @SuppressWarnings("unchecked")
    public HashMap<String, Medicamento> cargarInventario() {
        HashMap<String, Medicamento> resultado = (HashMap<String, Medicamento>) cargarObjeto(getRutaArchivo("inventario"));
        return resultado != null ? resultado : new HashMap<>();
    }

    public void guardarMedicamentosExpedidos(HashMap<String, Integer> medicamentosExpedidos) {
        guardarObjeto(getRutaArchivo("medicamentos"), medicamentosExpedidos);
    }

    @SuppressWarnings("unchecked")
    public HashMap<String, Integer> cargarMedicamentosExpedidos() {
        HashMap<String, Integer> resultado = (HashMap<String, Integer>) cargarObjeto(getRutaArchivo("medicamentos"));
        return resultado != null ? resultado : new HashMap<>();
    }

    private void guardarObjeto(String rutaArchivo, Object objeto) {
        try {
            File archivo = new File(rutaArchivo);
            if (!archivo.exists()) {
                archivo.getParentFile().mkdirs();
                archivo.createNewFile();
            }
            
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(archivo))) {
                oos.writeObject(objeto);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Object cargarObjeto(String rutaArchivo) {
        File archivo = new File(rutaArchivo);
        if (!archivo.exists()) {
            return null;
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            return ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            // Si hay error al cargar, eliminar el archivo corrupto
            archivo.delete();
            return null;
        }
    }
}