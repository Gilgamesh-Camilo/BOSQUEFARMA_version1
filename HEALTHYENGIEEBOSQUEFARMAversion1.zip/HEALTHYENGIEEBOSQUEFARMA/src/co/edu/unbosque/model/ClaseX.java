package co.edu.unbosque.model;

public class ClaseX {
    private SistemaBosqueFarma sistemaBF;

    public ClaseX() {
        sistemaBF = new SistemaBosqueFarma();
    }

    public String procesarOperacion(String operacion, String... datos) {
        return sistemaBF.ejecutarOperacion(operacion, datos);
    }
}