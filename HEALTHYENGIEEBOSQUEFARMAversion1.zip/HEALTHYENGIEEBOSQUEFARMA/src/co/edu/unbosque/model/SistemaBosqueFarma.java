package co.edu.unbosque.model;

import java.util.*;
import java.time.LocalDateTime;
import java.util.stream.Collectors;
import co.edu.unbosque.model.persistence.GestorDatos;

public class SistemaBosqueFarma {
    private ArrayList<Usuario> usuarios;
    private ArrayList<Funcionario> funcionarios;
    private Queue<Turno> turnos;
    private ArrayList<TurnoAtendido> turnosAtendidos;
    private HashMap<String, Medicamento> inventario;
    private HashMap<String, Integer> medicamentosExpedidos;
    private GestorDatos gestorDatos;

    public SistemaBosqueFarma() {
        gestorDatos = new GestorDatos();
        cargarDatos();
        inicializarInventarioBase();
    }

    private void cargarDatos() {
        usuarios = gestorDatos.cargarUsuarios();
        funcionarios = gestorDatos.cargarFuncionarios();
        turnos = new LinkedList<>(gestorDatos.cargarTurnos());
        turnosAtendidos = gestorDatos.cargarTurnosAtendidos();
        inventario = gestorDatos.cargarInventario();
        medicamentosExpedidos = gestorDatos.cargarMedicamentosExpedidos();

        if (usuarios == null) usuarios = new ArrayList<>();
        if (funcionarios == null) funcionarios = new ArrayList<>();
        if (turnos == null) turnos = new LinkedList<>();
        if (turnosAtendidos == null) turnosAtendidos = new ArrayList<>();
        if (inventario == null) inventario = new HashMap<>();
        if (medicamentosExpedidos == null) medicamentosExpedidos = new HashMap<>();
    }

    private void inicializarInventarioBase() {
        if (inventario.isEmpty()) {
            agregarMedicamento("001", "Paracetamol", 100, 5000);
            agregarMedicamento("002", "Ibuprofeno", 100, 6000);
            agregarMedicamento("003", "Amoxicilina", 50, 15000);
        }
    }

    public String ejecutarOperacion(String operacion, String... datos) {
        switch (operacion) {
            case "LOGIN":
                return login(datos[0], datos[1]);
            case "REGISTRO_FUNCIONARIO":
                return registrarFuncionario(datos[0], datos[1], datos[2], datos[3]);
            case "REGISTRO_USUARIO":
                return registrarUsuario(datos[0], datos[1], datos[2], datos[3]);
            case "GENERAR_TURNO":
                return generarTurno(datos[0]);
            case "ATENDER_TURNO":
                return atenderTurno(datos[0]);
            case "AGREGAR_MEDICAMENTO":
                return agregarMedicamento(datos[0], datos[1], 
                    Integer.parseInt(datos[2]), Double.parseDouble(datos[3]));
            case "EXPEDIR_MEDICAMENTO":
                return expedirMedicamento(datos[0], datos[1], Integer.parseInt(datos[2]));
            case "OBTENER_ESTADISTICAS":
                return generarEstadisticas();
            case "OBTENER_TURNOS":
                return obtenerTurnosActuales();
            case "OBTENER_INVENTARIO":
                return obtenerInventarioActual();
            case "LISTAR_FUNCIONARIOS":
                return listarFuncionarios();
            case "MODIFICAR_FUNCIONARIO":
                return modificarFuncionario(datos[0], datos[1], datos[2], datos[3]);
            case "ELIMINAR_FUNCIONARIO":
                return eliminarFuncionario(datos[0]);
            default:
                return "Operación no válida";
        }
    }

    private String login(String correo, String password) {
        if (!correo.endsWith("@bosquefarma.com.co")) {
            return "ERROR: El correo debe terminar en @bosquefarma.com.co";
        }

        Optional<Funcionario> funcionario = funcionarios.stream()
            .filter(f -> f.getCorreo().equals(correo) && f.getPassword().equals(password))
            .findFirst();
        if (funcionario.isPresent()) {
            return "Login exitoso|FUNCIONARIO";
        }

        Optional<Usuario> usuario = usuarios.stream()
            .filter(u -> u.getCorreo().equals(correo) && u.getPassword().equals(password))
            .findFirst();
        if (usuario.isPresent()) {
            return "Login exitoso|USUARIO";
        }

        return "Credenciales inválidas";
    }

    private String registrarFuncionario(String nombre, String documento, String password, String correo) {
        if (!correo.endsWith("@bosquefarma.com.co")) {
            return "ERROR: El correo debe terminar en @bosquefarma.com.co";
        }
        if (funcionarios.stream().anyMatch(f -> f.getDocumento().equals(documento))) {
            return "Ya existe un funcionario con ese documento";
        }
        
        Funcionario nuevo = new Funcionario(nombre, documento, password, correo);
        funcionarios.add(nuevo);
        gestorDatos.guardarFuncionarios(funcionarios);
        return "Funcionario registrado exitosamente";
    }

    private String registrarUsuario(String nombre, String documento, String password, String correo) {
        if (!correo.endsWith("@bosquefarma.com.co")) {
            return "ERROR: El correo debe terminar en @bosquefarma.com.co";
        }
        if (usuarios.stream().anyMatch(u -> u.getDocumento().equals(documento))) {
            return "Ya existe un usuario con ese documento";
        }
        
        Usuario nuevo = new Usuario(nombre, documento, password, correo);
        usuarios.add(nuevo);
        gestorDatos.guardarUsuarios(usuarios);
        return "Usuario registrado exitosamente";
    }

    private String generarTurno(String documento) {
        int numeroTurno = turnos.size() + turnosAtendidos.size() + 1;
        Turno nuevoTurno = new Turno(numeroTurno, documento);
        turnos.offer(nuevoTurno);
        gestorDatos.guardarTurnos(new ArrayList<>(turnos));
        return "Turno generado: " + numeroTurno;
    }

    private String atenderTurno(String idFuncionario) {
        Turno turno = turnos.poll();
        if (turno == null) {
            return "No hay turnos pendientes";
        }
        turno.setEstado("Atendido");
        turno.setFechaAtencion(LocalDateTime.now());
        Funcionario funcionario = funcionarios.stream()
            .filter(f -> f.getDocumento().equals(idFuncionario))
            .findFirst()
            .orElse(null);
        if (funcionario == null) {
            return "Funcionario no encontrado";
        }
        TurnoAtendido turnoAtendido = new TurnoAtendido(turno.getNumero(), LocalDateTime.now(), funcionario);
        turnosAtendidos.add(turnoAtendido);
        gestorDatos.guardarTurnos(new ArrayList<>(turnos));
        gestorDatos.guardarTurnosAtendidos(turnosAtendidos);
        return "Turno " + turno.getNumero() + " atendido";
    }

    private String agregarMedicamento(String codigo, String nombre, int cantidad, double precio) {
        Medicamento medicamento = new Medicamento(codigo, nombre, cantidad, precio);
        inventario.put(codigo, medicamento);
        gestorDatos.guardarInventario(inventario);
        return "Medicamento agregado exitosamente";
    }

    private String expedirMedicamento(String codigoMedicamento, String documentoPaciente, int cantidad) {
        Medicamento medicamento = inventario.get(codigoMedicamento);
        if (medicamento == null) {
            return "Medicamento no encontrado";
        }
        if (medicamento.getCantidad() < cantidad) {
            return "No hay suficiente cantidad del medicamento";
        }
        medicamento.setCantidad(medicamento.getCantidad() - cantidad);
        medicamentosExpedidos.merge(codigoMedicamento, cantidad, Integer::sum);
        gestorDatos.guardarInventario(inventario);
        gestorDatos.guardarMedicamentosExpedidos(medicamentosExpedidos);
        return "Medicamento expedido exitosamente";
    }

    private String generarEstadisticas() {
        StringBuilder stats = new StringBuilder();
        stats.append("Usuarios atendidos: ").append(turnosAtendidos.size()).append("\n\n");
        stats.append("Medicamentos expedidos:\n");
        medicamentosExpedidos.forEach((med, cant) -> 
            stats.append(med).append(": ").append(cant).append("\n"));
        stats.append("\nTop 5 medicamentos más expedidos:\n");
        medicamentosExpedidos.entrySet().stream()
            .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
            .limit(5)
            .forEach(e -> stats.append(e.getKey()).append(": ").append(e.getValue()).append("\n"));
        return stats.toString();
    }

    private String obtenerTurnosActuales() {
        StringBuilder turnosStr = new StringBuilder("Turnos actuales:\n");
        turnos.forEach(t -> turnosStr.append("Turno ").append(t.getNumero())
            .append(" - Documento: ").append(t.getDocumentoPaciente())
            .append(" - Estado: ").append(t.getEstado()).append("\n"));
        return turnosStr.toString();
    }

    private String obtenerInventarioActual() {
        StringBuilder invStr = new StringBuilder();
        inventario.values().forEach(m -> 
            invStr.append(m.getCodigo()).append("|")
            .append(m.getNombre()).append("|")
            .append(m.getCantidad()).append("|")
            .append(m.getPrecio()).append("\n"));
        return invStr.toString();
    }

    private String listarFuncionarios() {
        StringBuilder funcStr = new StringBuilder("Listado de Funcionarios:\n");
        funcionarios.forEach(f -> funcStr.append("Nombre: ").append(f.getNombre())
            .append(", Documento: ").append(f.getDocumento())
            .append(", Correo: ").append(f.getCorreo()).append("\n"));
        return funcStr.toString();
    }

    private String modificarFuncionario(String documento, String nuevoNombre, String nuevoPassword, String nuevoCorreo) {
        Optional<Funcionario> funcionario = funcionarios.stream()
            .filter(f -> f.getDocumento().equals(documento))
            .findFirst();
        if (funcionario.isPresent()) {
            Funcionario f = funcionario.get();
            f.setNombre(nuevoNombre);
            f.setPassword(nuevoPassword);
            f.setCorreo(nuevoCorreo);
            gestorDatos.guardarFuncionarios(funcionarios);
            return "Funcionario modificado exitosamente";
        }
        return "Funcionario no encontrado";
    }

    private String eliminarFuncionario(String documento) {
        boolean removido = funcionarios.removeIf(f -> f.getDocumento().equals(documento));
        if (removido) {
            gestorDatos.guardarFuncionarios(funcionarios);
            return "Funcionario eliminado exitosamente";
        }
        return "Funcionario no encontrado";
    }
}