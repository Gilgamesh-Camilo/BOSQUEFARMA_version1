package co.edu.unbosque.model;

import co.edu.unbosque.model.persistence.GestorDatos;
import java.time.LocalDateTime;
import java.util.ArrayList;

public class ClaseY {
    private GestorDatos gestorDatos;
    private ArrayList<Usuario> usuarios;
    private ArrayList<Funcionario> funcionarios;
    private ArrayList<Turno> turnos;
    private ArrayList<TurnoAtendido> turnosAtendidos;

    public ClaseY() {
        gestorDatos = new GestorDatos();
        cargarDatos();
    }

    public String procesarDatoClaseY(String dato) {
        // Implementa la lógica específica que necesites aquí
        return "Procesado: " + dato;
    }

    private void cargarDatos() {
        usuarios = gestorDatos.cargarUsuarios();
        funcionarios = gestorDatos.cargarFuncionarios();
        turnos = gestorDatos.cargarTurnos();
        turnosAtendidos = gestorDatos.cargarTurnosAtendidos();

        // Inicialización de colecciones si son null
        if (usuarios == null) usuarios = new ArrayList<>();
        if (funcionarios == null) funcionarios = new ArrayList<>();
        if (turnos == null) turnos = new ArrayList<>();
        if (turnosAtendidos == null) turnosAtendidos = new ArrayList<>();
    }

    public void guardarDatos() {
        gestorDatos.guardarUsuarios(usuarios);
        gestorDatos.guardarFuncionarios(funcionarios);
        gestorDatos.guardarTurnos(turnos);
        gestorDatos.guardarTurnosAtendidos(turnosAtendidos);
    }
}