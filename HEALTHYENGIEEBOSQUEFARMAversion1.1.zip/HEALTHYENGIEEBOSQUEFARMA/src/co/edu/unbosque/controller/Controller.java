package co.edu.unbosque.controller;

import co.edu.unbosque.model.ClaseX;
import co.edu.unbosque.view.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Controller implements ActionListener {
    private View vista;
    private ClaseX modelo;
    private String usuarioActual;
    private boolean esFuncionario;

    public Controller() {
        modelo = new ClaseX();
        vista = new View(this);
        inicializarVista();
    }

    private void inicializarVista() {
        vista.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String comando = e.getActionCommand();
        
        try {
            switch (comando) {
                // Comandos del menú principal
                case "INGRESAR_USUARIO":
                    vista.mostrarPanelLogin();
                    esFuncionario = false;
                    break;

                case "INGRESAR_FUNCIONARIO":
                    vista.mostrarPanelLogin();
                    esFuncionario = true;
                    break;

                case "LOGIN":
                    realizarLogin();
                    break;

                case "REGISTRAR_USUARIO":
                    vista.mostrarPanelRegistro();
                    esFuncionario = false;
                    break;

                case "REGISTRAR_FUNCIONARIO":
                    vista.mostrarPanelRegistro();
                    esFuncionario = true;
                    break;

                case PanelRegistro.COMANDO_REGISTRAR:
                    realizarRegistro();
                    break;

                case PanelRegistro.COMANDO_REGRESAR:
                    vista.volverAlMenuPrincipal();
                    break;

                // Comandos del panel de usuario
                case PanelPrincipalUsuario.COMANDO_GENERAR_TURNO:
                    generarTurno();
                    break;

                case PanelPrincipalUsuario.COMANDO_VER_TURNOS:
                    vista.mostrarPanelTurnos();
                    actualizarTurnosUsuario();
                    break;

                case PanelPrincipalUsuario.COMANDO_CERRAR_SESION:
                    cerrarSesion();
                    break;

                // Comandos del panel de funcionario
                case PanelPrincipalFuncionario.COMANDO_GESTIONAR_TURNOS:
                    vista.mostrarPanelTurnos();
                    actualizarTurnosFuncionario();
                    break;

                case PanelPrincipalFuncionario.COMANDO_GESTIONAR_INVENTARIO:
                    vista.mostrarPanelInventario();
                    actualizarInventario();
                    break;

                case PanelPrincipalFuncionario.COMANDO_VER_ESTADISTICAS:
                    mostrarEstadisticas();
                    break;

                // Comandos del panel de turnos
                case "ATENDER_TURNO":
                    atenderTurno();
                    break;

                case "CANCELAR_TURNO":
                    cancelarTurno();
                    break;

                case "VOLVER_TURNOS":
                    volverDesdePanel();
                    break;

                // Comandos del panel de inventario
                case "AGREGAR_MEDICAMENTO":
                    agregarMedicamento();
                    break;

                case "ACTUALIZAR_MEDICAMENTO":
                    actualizarMedicamento();
                    break;

                case "ELIMINAR_MEDICAMENTO":
                    eliminarMedicamento();
                    break;

                case "VOLVER_INVENTARIO":
                    volverDesdePanel();
                    break;

                // Comando del panel de estadísticas
                case "VOLVER_ESTADISTICAS":
                    volverDesdePanel();
                    break;

                default:
                    JOptionPane.showMessageDialog(vista, "Comando no reconocido: " + comando);
                    break;
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(vista, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void realizarLogin() {
        String cedula = vista.getPanelLogin().getTxtCedula().getText();
        String password = new String(vista.getPanelLogin().getTxtPassword().getPassword());

        String resultado = modelo.procesarOperacion("LOGIN", cedula, password);
        
        if (resultado.startsWith("Error")) {
            JOptionPane.showMessageDialog(vista, resultado);
            return;
        }

        usuarioActual = cedula;
        if (esFuncionario) {
            vista.mostrarPanelPrincipalFuncionario();
        } else {
            vista.mostrarPanelPrincipalUsuario();
        }
        JOptionPane.showMessageDialog(vista, "Bienvenido al sistema");
    }

    private void realizarRegistro() {
        PanelRegistro panel = vista.getPanelRegistro();
        String nombre = panel.getTxtNombre().getText();
        String cedula = panel.getTxtCedula().getText();
        String password = new String(panel.getTxtPassword().getPassword());
        String correo = panel.getTxtCorreo().getText();
        String celular = panel.getTxtCelular().getText();

        if (nombre.isEmpty() || cedula.isEmpty() || password.isEmpty() || 
            correo.isEmpty() || (esFuncionario && celular.isEmpty())) {
            JOptionPane.showMessageDialog(vista, "Todos los campos son obligatorios");
            return;
        }

        String resultado;
        if (esFuncionario) {
            resultado = modelo.procesarOperacion("REGISTRO_FUNCIONARIO", 
                nombre, cedula, password, correo, celular);
        } else {
            resultado = modelo.procesarOperacion("REGISTRO_USUARIO", 
                nombre, cedula, password, correo);
        }

        JOptionPane.showMessageDialog(vista, resultado);
        if (!resultado.startsWith("Error")) {
            panel.limpiarCampos();
            vista.volverAlMenuPrincipal();
        }
    }

    private void generarTurno() {
        if (usuarioActual == null) {
            JOptionPane.showMessageDialog(vista, "Debe iniciar sesión primero");
            return;
        }
        String resultado = modelo.procesarOperacion("GENERAR_TURNO", usuarioActual);
        JOptionPane.showMessageDialog(vista, resultado);
        actualizarTurnosUsuario();
    }

    private void actualizarTurnosUsuario() {
        String turnos = modelo.procesarOperacion("OBTENER_TURNOS_USUARIO", usuarioActual);
        vista.getPanelTurnos().actualizarTurnos(turnos);
    }

    private void actualizarTurnosFuncionario() {
        String turnos = modelo.procesarOperacion("OBTENER_TODOS_TURNOS");
        vista.getPanelTurnos().actualizarTurnos(turnos);
    }

    private void atenderTurno() {
        String turnoId = vista.getPanelTurnos().getTurnoSeleccionado();
        if (turnoId == null) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar un turno");
            return;
        }
        String resultado = modelo.procesarOperacion("ATENDER_TURNO", turnoId);
        JOptionPane.showMessageDialog(vista, resultado);
        actualizarTurnosFuncionario();
    }

    private void cancelarTurno() {
        String turnoId = vista.getPanelTurnos().getTurnoSeleccionado();
        if (turnoId == null) {
            JOptionPane.showMessageDialog(vista, "Debe seleccionar un turno");
            return;
        }
        String resultado = modelo.procesarOperacion("CANCELAR_TURNO", turnoId);
        JOptionPane.showMessageDialog(vista, resultado);
        if (esFuncionario) {
            actualizarTurnosFuncionario();
        } else {
            actualizarTurnosUsuario();
        }
    }

    private void actualizarInventario() {
        String inventario = modelo.procesarOperacion("OBTENER_INVENTARIO");
        vista.getPanelInventario().actualizarTabla(inventario);
    }

    private void agregarMedicamento() {
        // Implementar lógica para agregar medicamento
        // Usar los campos del panel de inventario
    }

    private void actualizarMedicamento() {
        // Implementar lógica para actualizar medicamento
        // Usar los campos del panel de inventario
    }

    private void eliminarMedicamento() {
        // Implementar lógica para eliminar medicamento
        // Usar el medicamento seleccionado en el panel de inventario
    }

    private void mostrarEstadisticas() {
        if (!esFuncionario) {
            JOptionPane.showMessageDialog(vista, "No tiene permisos para esta operación");
            return;
        }

        String estadisticas = modelo.procesarOperacion("OBTENER_ESTADISTICAS");
        vista.mostrarPanelEstadisticas();
        vista.getPanelEstadisticas().actualizarEstadisticas(estadisticas);
    }

    private void volverDesdePanel() {
        if (esFuncionario) {
            vista.mostrarPanelPrincipalFuncionario();
        } else {
            vista.mostrarPanelPrincipalUsuario();
        }
    }

    private void cerrarSesion() {
        usuarioActual = null;
        esFuncionario = false;
        vista.volverAlMenuPrincipal();
    }
}