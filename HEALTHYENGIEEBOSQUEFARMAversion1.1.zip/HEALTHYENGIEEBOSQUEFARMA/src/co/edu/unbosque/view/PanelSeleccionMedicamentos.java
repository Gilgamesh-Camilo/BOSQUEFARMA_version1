package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelSeleccionMedicamentos extends JPanel {
    private JComboBox<String> comboMedicamentos;
    private JSpinner spinnerCantidad;
    private JButton btnAgregar;
    private JTextArea areaPedido;

    public PanelSeleccionMedicamentos(ActionListener listener) {
        setLayout(new BorderLayout(10, 10));
        
        JPanel panelSeleccion = new JPanel(new GridLayout(3, 2, 5, 5));
        panelSeleccion.add(new JLabel("Medicamento:"));
        comboMedicamentos = new JComboBox<>();
        panelSeleccion.add(comboMedicamentos);
        
        panelSeleccion.add(new JLabel("Cantidad:"));
        spinnerCantidad = new JSpinner(new SpinnerNumberModel(1, 1, 100, 1));
        panelSeleccion.add(spinnerCantidad);
        
        btnAgregar = new JButton("Agregar al pedido");
        btnAgregar.setActionCommand("AGREGAR_MEDICAMENTO_PEDIDO");
        btnAgregar.addActionListener(listener);
        panelSeleccion.add(btnAgregar);
        
        add(panelSeleccion, BorderLayout.NORTH);
        
        areaPedido = new JTextArea(10, 30);
        areaPedido.setEditable(false);
        add(new JScrollPane(areaPedido), BorderLayout.CENTER);
    }

    // Métodos para actualizar la lista de medicamentos, agregar al pedido, etc.
}