package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelLogin extends JPanel {
	
    private JTextField txtCedula;
    private JPasswordField txtPassword;
    private JButton butLogin;
    private JButton butRegresar;
    public static final String COMANDO_LOGIN = "LOGIN";
    public static final String COMANDO_REGRESAR = "REGRESAR";

    public PanelLogin(ActionListener listener) {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Panel principal con borde y padding
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("Inicio de Sesión"),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        // Título
        JLabel titulo = new JLabel("Bienvenido a BosqueFarma");
        titulo.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(titulo, gbc);

        // Campos de entrada
        JLabel lblCedula = new JLabel("Cédula:");
        txtCedula = new JTextField(15);
        JLabel lblPassword = new JLabel("Contraseña:");
        txtPassword = new JPasswordField(15);

        gbc.gridwidth = 1;
        gbc.gridy = 1;
        add(lblCedula, gbc);
        gbc.gridx = 1;
        add(txtCedula, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        add(lblPassword, gbc);
        gbc.gridx = 1;
        add(txtPassword, gbc);

        // Panel de botones
        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        butLogin = new JButton("Iniciar Sesión");
        butRegresar = new JButton("Regresar");
        
        butLogin.setActionCommand(COMANDO_LOGIN);
        butRegresar.setActionCommand(COMANDO_REGRESAR);
        
        buttonPanel.add(butLogin);
        buttonPanel.add(butRegresar);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        add(buttonPanel, gbc);

        // Configurar listeners
        butLogin.addActionListener(listener);
        butRegresar.addActionListener(listener);
    }

    // Getters
    public JTextField getTxtCedula() { return txtCedula; }
    public JPasswordField getTxtPassword() { return txtPassword; }
    public void limpiarCampos() {
        txtCedula.setText("");
        txtPassword.setText("");
    }
}