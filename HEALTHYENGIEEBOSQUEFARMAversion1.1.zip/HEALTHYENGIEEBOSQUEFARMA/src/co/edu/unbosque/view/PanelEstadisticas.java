package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelEstadisticas extends JPanel {
    private JTextArea txtEstadisticas;
    private JButton btnVolver;
    public static final String COMANDO_VOLVER = "VOLVER_ESTADISTICAS";

    public PanelEstadisticas() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        initComponents();
    }

    private void initComponents() {
        // Panel superior para título
        JPanel panelTitulo = new JPanel();
        JLabel lblTitulo = new JLabel("Estadísticas del Sistema");
        lblTitulo.setFont(new Font("Arial", Font.BOLD, 18));
        panelTitulo.add(lblTitulo);
        add(panelTitulo, BorderLayout.NORTH);

        // Panel central para estadísticas
        txtEstadisticas = new JTextArea();
        txtEstadisticas.setEditable(false);
        txtEstadisticas.setFont(new Font("Monospaced", Font.PLAIN, 14));
        JScrollPane scrollPane = new JScrollPane(txtEstadisticas);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        add(scrollPane, BorderLayout.CENTER);

        // Panel inferior para botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnVolver = new JButton("Volver");
        btnVolver.setActionCommand(COMANDO_VOLVER);
        panelBotones.add(btnVolver);
        add(panelBotones, BorderLayout.SOUTH);
    }

    public void actualizarEstadisticas(String estadisticas) {
        txtEstadisticas.setText(estadisticas);
        txtEstadisticas.setCaretPosition(0);
    }

    public void setActionListener(ActionListener listener) {
        btnVolver.addActionListener(listener);
    }

    public JTextArea getTxtEstadisticas() {
        return txtEstadisticas;
    }

    public JButton getBtnVolver() {
        return btnVolver;
    }
}