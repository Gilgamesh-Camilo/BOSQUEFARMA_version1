package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelPrincipal extends JPanel {
    private JButton btnVerTurnos;
    private JButton btnVerInventario;
    private JButton btnVerEstadisticas;
    private JButton btnCerrarSesion;
    
    public static final String COMANDO_MOSTRAR_TURNOS = "MOSTRAR_TURNOS";
    public static final String COMANDO_MOSTRAR_INVENTARIO = "MOSTRAR_INVENTARIO";
    public static final String COMANDO_VER_ESTADISTICAS = "VER_ESTADISTICAS";
    public static final String COMANDO_CERRAR_SESION = "CERRAR_SESION";
    
    public PanelPrincipal() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // Crear título
        JLabel titulo = new JLabel("Panel Principal - BosqueFarma", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 24));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        add(titulo, gbc);
        
        // Panel para los botones
        JPanel panelBotones = new JPanel(new GridBagLayout());
        panelBotones.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        // Crear botones
        btnVerTurnos = crearBoton("Ver Turnos", COMANDO_MOSTRAR_TURNOS);
        btnVerInventario = crearBoton("Ver Inventario", COMANDO_MOSTRAR_INVENTARIO);
        btnVerEstadisticas = crearBoton("Ver Estadísticas", COMANDO_VER_ESTADISTICAS);
        btnCerrarSesion = crearBoton("Cerrar Sesión", COMANDO_CERRAR_SESION);
        
        // Agregar botones al panel
        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 0;
        panelBotones.add(btnVerTurnos, gbc);
        
        gbc.gridx = 1;
        panelBotones.add(btnVerInventario, gbc);
        
        gbc.gridx = 0;
        gbc.gridy = 1;
        panelBotones.add(btnVerEstadisticas, gbc);
        
        gbc.gridx = 1;
        panelBotones.add(btnCerrarSesion, gbc);
        
        // Agregar panel de botones al panel principal
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        add(panelBotones, gbc);
    }
    
    private JButton crearBoton(String texto, String comando) {
        JButton boton = new JButton(texto);
        boton.setActionCommand(comando);
        boton.setPreferredSize(new Dimension(200, 40));
        return boton;
    }
    
    public void configurarBotones(ActionListener listener) {
        btnVerTurnos.addActionListener(listener);
        btnVerInventario.addActionListener(listener);
        btnVerEstadisticas.addActionListener(listener);
        btnCerrarSesion.addActionListener(listener);
    }
    
    public void actualizarVista(boolean esFuncionario) {
        // Mostrar/ocultar botones según el tipo de usuario
        btnVerInventario.setVisible(esFuncionario);
        btnVerEstadisticas.setVisible(esFuncionario);
        // El botón de turnos y cerrar sesión están disponibles para todos
    }
}