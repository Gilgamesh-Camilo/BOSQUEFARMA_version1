package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelPrincipalUsuario extends JPanel {
	
    private JButton btnGenerarTurno;
    private JButton btnVerMisTurnos;
    private JButton btnCerrarSesion;
    
    public static final String COMANDO_GENERAR_TURNO = "GENERAR_TURNO_USUARIO";
    public static final String COMANDO_VER_TURNOS = "VER_MIS_TURNOS";
    public static final String COMANDO_CERRAR_SESION = "CERRAR_SESION";

    public PanelPrincipalUsuario(ActionListener listener) {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("Panel de Usuario"),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        // Título
        JLabel titulo = new JLabel("Bienvenido Usuario", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 1;
        add(titulo, gbc);

        // Botones
        JPanel panelBotones = new JPanel(new GridLayout(4, 1, 10, 10));
        
        btnGenerarTurno = new JButton("Generar Nuevo Turno");
        btnVerMisTurnos = new JButton("Ver Mis Turnos");
        btnCerrarSesion = new JButton("Cerrar Sesión");
        
        btnGenerarTurno.setActionCommand(COMANDO_GENERAR_TURNO);
        btnVerMisTurnos.setActionCommand(COMANDO_VER_TURNOS);
        btnCerrarSesion.setActionCommand(COMANDO_CERRAR_SESION);
        
        panelBotones.add(btnGenerarTurno);
        panelBotones.add(btnVerMisTurnos);
        panelBotones.add(new JLabel("")); // Espaciador
        panelBotones.add(btnCerrarSesion);

        gbc.gridy = 1;
        add(panelBotones, gbc);

        // Configurar listeners
        btnGenerarTurno.addActionListener(listener);
        btnVerMisTurnos.addActionListener(listener);
        btnCerrarSesion.addActionListener(listener);
    }
}
