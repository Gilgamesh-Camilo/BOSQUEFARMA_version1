package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelPrincipalFuncionario extends JPanel {
    private JButton btnGestionarTurnos;
    private JButton btnGestionarInventario;
    private JButton btnVerEstadisticas;
    private JButton btnCerrarSesion;
    
    public static final String COMANDO_GESTIONAR_TURNOS = "GESTIONAR_TURNOS";
    public static final String COMANDO_GESTIONAR_INVENTARIO = "GESTIONAR_INVENTARIO";
    public static final String COMANDO_VER_ESTADISTICAS = "VER_ESTADISTICAS";
    public static final String COMANDO_CERRAR_SESION = "CERRAR_SESION";

    public PanelPrincipalFuncionario(ActionListener listener) {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("Panel de Funcionario"),
            BorderFactory.createEmptyBorder(20, 20, 20, 20)
        ));

        // Título
        JLabel titulo = new JLabel("Bienvenido Funcionario", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 20));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 1;
        add(titulo, gbc);

        // Botones
        JPanel panelBotones = new JPanel(new GridLayout(5, 1, 10, 10));
        
        btnGestionarTurnos = new JButton("Gestionar Turnos");
        btnGestionarInventario = new JButton("Gestionar Inventario");
        btnVerEstadisticas = new JButton("Ver Estadísticas");
        btnCerrarSesion = new JButton("Cerrar Sesión");
        
        btnGestionarTurnos.setActionCommand(COMANDO_GESTIONAR_TURNOS);
        btnGestionarInventario.setActionCommand(COMANDO_GESTIONAR_INVENTARIO);
        btnVerEstadisticas.setActionCommand(COMANDO_VER_ESTADISTICAS);
        btnCerrarSesion.setActionCommand(COMANDO_CERRAR_SESION);
        
        panelBotones.add(btnGestionarTurnos);
        panelBotones.add(btnGestionarInventario);
        panelBotones.add(btnVerEstadisticas);
        panelBotones.add(new JLabel("")); // Espaciador
        panelBotones.add(btnCerrarSesion);

        gbc.gridy = 1;
        add(panelBotones, gbc);

        // Configurar listeners
        btnGestionarTurnos.addActionListener(listener);
        btnGestionarInventario.addActionListener(listener);
        btnVerEstadisticas.addActionListener(listener);
        btnCerrarSesion.addActionListener(listener);
    }
}