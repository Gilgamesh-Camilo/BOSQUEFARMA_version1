package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class View extends JFrame {
    private PanelMenuPrincipal panelMenuPrincipal;
    private PanelLogin panelLogin;
    private PanelRegistro panelRegistro;
    private PanelPrincipalUsuario panelPrincipalUsuario;
    private PanelPrincipalFuncionario panelPrincipalFuncionario;
    private PanelTurnos panelTurnos;
    private PanelInventario panelInventario;
    private Object panelEstadisticas;
    private CardLayout cardLayout;
    private JPanel contentPane;

    private static final String MENU_PRINCIPAL = "menu_principal";
    private static final String LOGIN = "login";
    private static final String REGISTRO = "registro";
    private static final String PRINCIPAL_USUARIO = "principal_usuario";
    private static final String PRINCIPAL_FUNCIONARIO = "principal_funcionario";
    private static final String TURNOS = "turnos";
    private static final String INVENTARIO = "inventario";
    private static final String ESTADISTICAS = "estadisticas";

    public View(ActionListener listener) {
        setTitle("Sistema BosqueFarma");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);
        setResizable(false);
        initComponents(listener);
    }

    private void initComponents(ActionListener listener) {
        cardLayout = new CardLayout();
        contentPane = new JPanel(cardLayout);
        setContentPane(contentPane);

        // Inicializar todos los paneles
        panelMenuPrincipal = new PanelMenuPrincipal(listener);
        panelLogin = new PanelLogin(listener);
        panelRegistro = new PanelRegistro();
        panelRegistro.configurarBotones(listener);
        
        panelPrincipalUsuario = new PanelPrincipalUsuario(listener);
        panelPrincipalFuncionario = new PanelPrincipalFuncionario(listener);
        
        panelEstadisticas = new PanelEstadisticas();
        ((PanelEstadisticas) panelEstadisticas).setActionListener(listener);
        
        panelTurnos = new PanelTurnos();
        panelTurnos.configurarBotones(listener);
        
        panelInventario = new PanelInventario();
        panelInventario.configurarBotones(listener);
        
        panelEstadisticas = new PanelEstadisticas();

        // Agregar paneles al contentPane
        contentPane.add(panelMenuPrincipal, MENU_PRINCIPAL);
        contentPane.add(panelLogin, LOGIN);
        contentPane.add(panelRegistro, REGISTRO);
        contentPane.add(panelPrincipalUsuario, PRINCIPAL_USUARIO);
        contentPane.add(panelPrincipalFuncionario, PRINCIPAL_FUNCIONARIO);
        contentPane.add(panelTurnos, TURNOS);
        contentPane.add(panelInventario, INVENTARIO);
        contentPane.add((Component) panelEstadisticas, ESTADISTICAS);

        // Mostrar el panel inicial
        cardLayout.show(contentPane, MENU_PRINCIPAL);
    }

    public void mostrarPanelLogin() {
        cardLayout.show(contentPane, LOGIN);
    }

    public void mostrarPanelRegistro() {
        cardLayout.show(contentPane, REGISTRO);
    }

    public void mostrarPanelPrincipalUsuario() {
        cardLayout.show(contentPane, PRINCIPAL_USUARIO);
    }

    public void mostrarPanelPrincipalFuncionario() {
        cardLayout.show(contentPane, PRINCIPAL_FUNCIONARIO);
    }

    public void mostrarPanelTurnos() {
        cardLayout.show(contentPane, TURNOS);
    }

    public void mostrarPanelInventario() {
        cardLayout.show(contentPane, INVENTARIO);
    }

    public void mostrarPanelEstadisticas() {
        cardLayout.show(contentPane, ESTADISTICAS);
    }

    public void volverAlMenuPrincipal() {
        cardLayout.show(contentPane, MENU_PRINCIPAL);
    }

    // Getters para todos los paneles
    public PanelMenuPrincipal getPanelMenuPrincipal() { return panelMenuPrincipal; }
    public PanelLogin getPanelLogin() { return panelLogin; }
    public PanelRegistro getPanelRegistro() { return panelRegistro; }
    public PanelPrincipalUsuario getPanelPrincipalUsuario() { return panelPrincipalUsuario; }
    public PanelPrincipalFuncionario getPanelPrincipalFuncionario() { return panelPrincipalFuncionario; }
    public PanelTurnos getPanelTurnos() { return panelTurnos; }
    public PanelInventario getPanelInventario() { return panelInventario; }
    public PanelEstadisticas getPanelEstadisticas() { return (PanelEstadisticas) panelEstadisticas; }

	public void mostrarPanelPrincipal() {
		// TODO Auto-generated method stub
		
	}

	public Object getPanelPrincipal() {
		// TODO Auto-generated method stub
		return null;
	}
}