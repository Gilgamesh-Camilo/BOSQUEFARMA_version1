package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelRegistro extends JPanel {
    private JTextField txtNombre;
    private JTextField txtCedula;
    private JPasswordField txtPassword;
    private JTextField txtCorreo;
    private JTextField txtCelular;
    private JButton butRegistrar;
    private JButton butRegresar;
    
    public static final String COMANDO_REGISTRAR = "REGISTRAR";
    public static final String COMANDO_REGRESAR = "REGRESAR";

    public PanelRegistro() {
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        
        setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createTitledBorder("Registro de Usuario"),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));

        // Panel para campos
        JPanel panelCampos = new JPanel(new GridLayout(6, 2, 10, 10));
        
        panelCampos.add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        panelCampos.add(txtNombre);

        panelCampos.add(new JLabel("Cédula:"));
        txtCedula = new JTextField();
        panelCampos.add(txtCedula);

        panelCampos.add(new JLabel("Contraseña:"));
        txtPassword = new JPasswordField();
        panelCampos.add(txtPassword);

        panelCampos.add(new JLabel("Correo:"));
        txtCorreo = new JTextField();
        panelCampos.add(txtCorreo);

        panelCampos.add(new JLabel("Celular:"));
        txtCelular = new JTextField();
        panelCampos.add(txtCelular);

        gbc.gridx = 0; gbc.gridy = 0;
        add(panelCampos, gbc);

        // Panel de botones
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        butRegistrar = new JButton("Registrar");
        butRegresar = new JButton("Regresar");
        
        butRegistrar.setActionCommand(COMANDO_REGISTRAR);
        butRegresar.setActionCommand(COMANDO_REGRESAR);
        
        panelBotones.add(butRegistrar);
        panelBotones.add(butRegresar);

        gbc.gridy = 1;
        add(panelBotones, gbc);
    }

    public void configurarBotones(ActionListener listener) {
        butRegistrar.addActionListener(listener);
        butRegresar.addActionListener(listener);
    }

    // Getters
    public JTextField getTxtNombre() { return txtNombre; }
    public JTextField getTxtCedula() { return txtCedula; }
    public JPasswordField getTxtPassword() { return txtPassword; }
    public JTextField getTxtCorreo() { return txtCorreo; }
    public JTextField getTxtCelular() { return txtCelular; }
    
    public void limpiarCampos() {
        txtNombre.setText("");
        txtCedula.setText("");
        txtPassword.setText("");
        txtCorreo.setText("");
        txtCelular.setText("");
    }
}