package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class PanelEdicionMedicamentos extends JPanel {
	
    private JComboBox<String> comboMedicamentos;
    private JTextField txtNombre;
    private JTextField txtCantidad;
    private JTextField txtPrecio;
    private JButton btnEditar;

    public PanelEdicionMedicamentos(ActionListener listener) {
        setLayout(new GridLayout(5, 2, 10, 10));
        
        add(new JLabel("Seleccionar medicamento:"));
        comboMedicamentos = new JComboBox<>();
        add(comboMedicamentos);
        
        add(new JLabel("Nombre:"));
        txtNombre = new JTextField();
        add(txtNombre);
        
        add(new JLabel("Cantidad:"));
        txtCantidad = new JTextField();
        add(txtCantidad);
        
        add(new JLabel("Precio:"));
        txtPrecio = new JTextField();
        add(txtPrecio);
        
        btnEditar = new JButton("Editar Medicamento");
        btnEditar.setActionCommand("EDITAR_MEDICAMENTO");
        btnEditar.addActionListener(listener);
        add(btnEditar);
    }

    // Métodos para actualizar la información del medicamento seleccionado, etc.
}
