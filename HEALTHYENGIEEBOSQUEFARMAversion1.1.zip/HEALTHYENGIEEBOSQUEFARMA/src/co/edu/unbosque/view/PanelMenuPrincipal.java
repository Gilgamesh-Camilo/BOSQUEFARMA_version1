package co.edu.unbosque.view;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

import co.edu.unbosque.controller.Controller;

public class PanelMenuPrincipal extends JPanel {
	
    private JButton btnIngresarUsuario;
    private JButton btnIngresarFuncionario;
    private JButton btnRegistrarUsuario;
    private JButton btnRegistrarFuncionario;

    public PanelMenuPrincipal(ActionListener listener) {
    	
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel titulo = new JLabel("BosqueFarma - Sistema de Farmacia", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 18));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        add(titulo, gbc);

        btnIngresarUsuario = new JButton("Ingresar como Usuario");
        btnIngresarFuncionario = new JButton("Ingresar como Funcionario");
        btnRegistrarUsuario = new JButton("Registrar Usuario");
        btnRegistrarFuncionario = new JButton("Registrar Funcionario");

        gbc.gridwidth = 1; gbc.gridy = 1;
        add(btnIngresarUsuario, gbc);
        gbc.gridx = 1;
        add(btnIngresarFuncionario, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        add(btnRegistrarUsuario, gbc);
        gbc.gridx = 1;
        add(btnRegistrarFuncionario, gbc);

        btnIngresarUsuario.addActionListener(listener);
        btnIngresarFuncionario.addActionListener(listener);
        btnRegistrarUsuario.addActionListener(listener);
        btnRegistrarFuncionario.addActionListener(listener);

        btnIngresarUsuario.setActionCommand("INGRESAR_USUARIO");
        btnIngresarFuncionario.setActionCommand("INGRESAR_FUNCIONARIO");
        btnRegistrarUsuario.setActionCommand("REGISTRAR_USUARIO");
        btnRegistrarFuncionario.setActionCommand("REGISTRAR_FUNCIONARIO");
    }
}