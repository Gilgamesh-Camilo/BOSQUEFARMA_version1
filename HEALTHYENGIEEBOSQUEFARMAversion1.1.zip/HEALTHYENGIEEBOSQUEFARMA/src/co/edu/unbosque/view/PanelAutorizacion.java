package co.edu.unbosque.view;

import javax.swing.text.JTextComponent;

public class PanelAutorizacion {

	public JTextComponent getTxtCedulaUsuario() {
		// TODO Auto-generated method stub
		return null;
	}

}
