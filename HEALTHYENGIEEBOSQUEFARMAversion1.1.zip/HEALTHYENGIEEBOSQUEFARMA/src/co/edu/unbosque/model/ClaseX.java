package co.edu.unbosque.model;

public class ClaseX {
    private SistemaBosqueFarma sistemaBF;

    public ClaseX() {
        sistemaBF = new SistemaBosqueFarma();
    }

    public String procesarOperacion(String operacion, String... datos) {
        try {
            switch (operacion) {
                case "LOGIN":
                    validarCantidadParametros(datos, 2);
                    return sistemaBF.login(datos[0], datos[1]);

                case "REGISTRO_USUARIO":
                    validarCantidadParametros(datos, 3);
                    return sistemaBF.registrarUsuario(datos[0], datos[1], datos[2]);

                case "REGISTRO_FUNCIONARIO":
                    validarCantidadParametros(datos, 5);
                    return sistemaBF.registrarFuncionario(datos[0], datos[1], datos[2], datos[3], datos[4]);

                case "GENERAR_TURNO":
                    validarCantidadParametros(datos, 1);
                    return sistemaBF.generarTurno(datos[0]);

                case "ATENDER_TURNO":
                    validarCantidadParametros(datos, 1);
                    return sistemaBF.atenderTurno(datos[0]);

                case "AGREGAR_MEDICAMENTO":
                    validarCantidadParametros(datos, 4);
                    return sistemaBF.agregarMedicamento(
                        datos[0],
                        datos[1],
                        Integer.parseInt(datos[2]),
                        Double.parseDouble(datos[3]), operacion
                    );

                case "EDITAR_MEDICAMENTO":
                    validarCantidadParametros(datos, 4);
                    return sistemaBF.editarMedicamento(
                        datos[0],
                        datos[1],
                        Integer.parseInt(datos[2]),
                        Double.parseDouble(datos[3])
                    );

                case "OBTENER_TURNOS":
                    return sistemaBF.obtenerTurnosActuales();

                case "OBTENER_INVENTARIO":
                    return sistemaBF.obtenerInventarioActual();

                case "OBTENER_ESTADISTICAS":
                    return sistemaBF.generarEstadisticas();

                case "AUTORIZAR_USUARIO":
                    validarCantidadParametros(datos, 2);
                    return sistemaBF.autorizarUsuario(datos[0], datos[1]);

                case "EXPEDIR_MEDICAMENTO":
                    validarCantidadParametros(datos, 3);
                    return sistemaBF.expedirMedicamento(
                        datos[0],
                        datos[1],
                        Integer.parseInt(datos[2])
                    );

                default:
                    return "Operación no válida: " + operacion;
            }
        } catch (NumberFormatException e) {
            return "Error: Formato de número inválido - " + e.getMessage();
        } catch (ArrayIndexOutOfBoundsException e) {
            return "Error: Faltan parámetros para la operación";
        } catch (Exception e) {
            return "Error inesperado: " + e.getMessage();
        }
    }

    private void validarCantidadParametros(String[] datos, int cantidadRequerida) {
        if (datos == null || datos.length < cantidadRequerida) {
            throw new IllegalArgumentException(
                "La operación requiere " + cantidadRequerida + " parámetros, pero se proporcionaron " +
                (datos == null ? 0 : datos.length)
            );
        }
    }
}