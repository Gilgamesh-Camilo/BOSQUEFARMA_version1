package co.edu.unbosque.model;

import java.time.LocalDateTime;
import java.util.Map;
import java.util.HashMap;
import java.util.Optional;
import java.util.Queue;
import java.util.LinkedList;
import java.util.ArrayList;

import co.edu.unbosque.model.persistence.*;

public class SistemaBosqueFarma {
	
    private UsuarioDAO usuarioDAO;
    private FuncionarioDAO funcionarioDAO;
    private MedicamentoDAO medicamentoDAO;
    private TurnoDAO turnoDAO;
    private TurnoAtendidoDAO turnoAtendidoDAO;
    private Map<String, Integer> medicamentosExpedidos;
    private Queue<TurnoDAO> turnos;

    public SistemaBosqueFarma() {
        usuarioDAO = new UsuarioDAO();
        funcionarioDAO = new FuncionarioDAO();
        medicamentoDAO = new MedicamentoDAO();
        turnoDAO = new TurnoDAO();
        turnoAtendidoDAO = new TurnoAtendidoDAO();
        medicamentosExpedidos = new HashMap<>();
        turnos = new LinkedList<>();
        inicializarInventarioBase();
    }

    public String login(String cedula, String password) {
        FuncionarioDTO funcionario = (FuncionarioDTO) funcionarioDAO.leer(cedula);
        if (funcionario != null && funcionario.getPassword().equals(password)) {
            return "Login exitoso|FUNCIONARIO";
        }

        UsuarioDTO usuario = usuarioDAO.leer(cedula);
        if (usuario != null && usuario.isAutorizado()) {
            return "Login exitoso|USUARIO";
        }

        return "Credenciales inválidas o usuario no autorizado";
    }

    public String registrarUsuario(String nombre, String cedula, String numeroCelular) {
        UsuarioDTO nuevoUsuario = new UsuarioDTO(nombre, cedula, numeroCelular);
        if (usuarioDAO.crear(nuevoUsuario)) {
            return "Usuario registrado exitosamente. Esperando autorización de un funcionario.";
        }
        return "Error al registrar usuario: Ya existe un usuario con esa cédula";
    }

    public String registrarFuncionario(String nombre, String cedula, String password, String correo, String cargo) {
        FuncionarioDTO nuevoFuncionario = new FuncionarioDTO(nombre, cedula, password, correo, cargo);
        if (funcionarioDAO.crear(nuevoFuncionario)) {
            return "Funcionario registrado exitosamente";
        }
        return "Error al registrar funcionario: Ya existe un funcionario con esa cédula";
    }

    public String autorizarUsuario(String cedulaUsuario, String cedulaFuncionario) {
        UsuarioDTO usuario = usuarioDAO.leer(cedulaUsuario);
        FuncionarioDTO funcionario = (FuncionarioDTO) funcionarioDAO.leer(cedulaFuncionario);
        
        if (usuario != null && funcionario != null && !usuario.isAutorizado()) {
            usuario.setAutorizado(true);
            usuarioDAO.actualizar(usuario);
            return "Usuario autorizado exitosamente";
        }
        return "Usuario no encontrado o ya autorizado";
    }

    public String generarTurno(String documento) {
        int numeroTurno = turnos.size() + turnoAtendidoDAO.obtenerTodos().size() + 1;
        TurnoDAO nuevoTurno = new TurnoDAO();
        turnos.offer(nuevoTurno);
        turnoDAO.guardarTurnos(new ArrayList<>(turnos));
        return "Turno generado: " + numeroTurno;
    }

    public String atenderTurno(String idFuncionario) {
        TurnoDAO turno = turnos.poll();
        if (turno == null) {
            return "No hay turnos pendientes";
        }

        FuncionarioDTO funcionario = (FuncionarioDTO) funcionarioDAO.leer(idFuncionario);
        if (funcionario == null) {
            return "Funcionario no encontrado";
        }

        turno.setEstado("Atendido");
        turno.setFechaAtencion(LocalDateTime.now());
        
        TurnoAtendidoDTO turnoAtendido = new TurnoAtendidoDTO(
            turno.getNumero(), 
            LocalDateTime.now(), 
            funcionario
        );
        
        turnoAtendidoDAO.crear(turnoAtendido);
        turnoDAO.guardarTurnos(new ArrayList<>(turnos));
        return "Turno " + turno.getNumero() + " atendido";
    }

    public String agregarMedicamento(String codigo, String nombre, int cantidad, double precio, String laboratorio) {
        MedicamentoDTO medicamento = new MedicamentoDTO(codigo, nombre, cantidad, precio, laboratorio);
        if (medicamentoDAO.crear(medicamento)) {
            return "Medicamento agregado exitosamente";
        }
        return "Error al agregar medicamento: Ya existe un medicamento con ese código";
    }

    public String editarMedicamento(String codigo, String nombre, int cantidad, double precio) {
        MedicamentoDTO medicamento = medicamentoDAO.leer(codigo);
        if (medicamento != null) {
            medicamento.setNombre(nombre);
            medicamento.setCantidad(cantidad);
            medicamento.setPrecio(precio);
            medicamentoDAO.actualizar(medicamento);
            return "Medicamento actualizado exitosamente";
        }
        return "Medicamento no encontrado";
    }

    private void inicializarInventarioBase() {
        if (medicamentoDAO.obtenerTodos().isEmpty()) {
            agregarMedicamento("001", "Paracetamol", 100, 5000, null);
            agregarMedicamento("002", "Ibuprofeno", 100, 6000, null);
            agregarMedicamento("003", "Amoxicilina", 50, 15000, null);
        }
    }

    public String expedirMedicamento(String codigoMedicamento, String documentoPaciente, int cantidad) {
        MedicamentoDTO medicamento = medicamentoDAO.leer(codigoMedicamento);
        if (medicamento == null) {
            return "Medicamento no encontrado";
        }
        if (medicamento.getCantidad() < cantidad) {
            return "No hay suficiente cantidad del medicamento";
        }
        
        medicamento.setCantidad(medicamento.getCantidad() - cantidad);
        medicamentoDAO.actualizar(medicamento);
        medicamentosExpedidos.merge(codigoMedicamento, cantidad, Integer::sum);
        return "Medicamento expedido exitosamente";
    }

    public String obtenerTurnosActuales() {
        StringBuilder turnosStr = new StringBuilder("Turnos actuales:\n");
        turnos.forEach(t -> turnosStr.append("Turno ").append(t.getNumero())
            .append(" - Documento: ").append(t.getDocumentoPaciente())
            .append(" - Estado: ").append(t.getEstado()).append("\n"));
        return turnosStr.toString();
    }

    public String obtenerInventarioActual() {
        Map<String, MedicamentoDTO> inventario = medicamentoDAO.obtenerTodos();
        if (inventario == null || inventario.isEmpty()) {
            return "No hay medicamentos en el inventario";
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append("Inventario actual:\n");
        sb.append("Código\tNombre\tCantidad\tPrecio\n");
        
        inventario.forEach((codigo, med) -> {
            sb.append(String.format("%s\t%s\t%d\t%.2f\n",
                med.getCodigo(),
                med.getNombre(),
                med.getCantidad(),
                med.getPrecio()));
        });
        
        return sb.toString();
    }


    public String generarEstadisticas() {
        StringBuilder stats = new StringBuilder();
        stats.append("Usuarios atendidos: ").append(turnoAtendidoDAO.obtenerTodos().size()).append("\n\n");
        
        stats.append("Medicamentos expedidos:\n");
        medicamentosExpedidos.forEach((med, cant) -> 
            stats.append(med).append(": ").append(cant).append("\n"));
        
        stats.append("\nTop 5 medicamentos más expedidos:\n");
        medicamentosExpedidos.entrySet().stream()
            .sorted(Map.Entry.<String, Integer>comparingByValue().reversed())
            .limit(5)
            .forEach(e -> stats.append(e.getKey()).append(": ").append(e.getValue()).append("\n"));
        
        return stats.toString();
    }
}