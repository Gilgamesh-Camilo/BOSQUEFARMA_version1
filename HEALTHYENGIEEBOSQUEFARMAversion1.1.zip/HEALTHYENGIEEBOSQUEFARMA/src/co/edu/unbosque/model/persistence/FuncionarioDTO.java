package co.edu.unbosque.model.persistence;

public class FuncionarioDTO extends UsuarioDTO {
	
    private static final long serialVersionUID = 1L;
    private String password;
    private String correo;
    
    public FuncionarioDTO(String nombre, String cedula, String numeroCelular, String password, String correo) {
        super(nombre, cedula, numeroCelular);
        this.password = password;
        this.correo = correo;
        setAutorizado(true);
    }
    
    // Getters y Setters adicionales
    public String getPassword() { return password; }
    public void setPassword(String password) { this.password = password; }
    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }
}