package co.edu.unbosque.model.persistence;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public interface IDAO {
	
    boolean crear(Object objeto);
    Object leer(String id);
    boolean actualizar(Object objeto);
    boolean eliminar(String id);
    List<?> listarTodos();
	boolean crear(MedicamentoDTO objeto);
	boolean actualizar(MedicamentoDTO objeto);
	boolean crear(TurnoDTO objeto);
	boolean actualizar(TurnoDTO objeto);
	boolean crear(UsuarioDTO objeto);
	boolean actualizar(UsuarioDTO objeto);
}

