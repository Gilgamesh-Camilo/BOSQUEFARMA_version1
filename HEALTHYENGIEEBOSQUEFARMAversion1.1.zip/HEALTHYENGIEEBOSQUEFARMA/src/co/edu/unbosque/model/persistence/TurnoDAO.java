package co.edu.unbosque.model.persistence;

import java.io.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class TurnoDAO implements IDAO {
    private static final String ARCHIVO_TURNOS = "data/turnos.dat";
    private Queue<TurnoDTO> turnos;
    private String documentoPaciente;
    private String estado;
    private LocalDateTime fechaAtencion;
    private int numero;

    public TurnoDAO() {
        turnos = new LinkedList<>();
        cargarDatos();
    }

    private void cargarDatos() {
        File directorio = new File("data");
        if (!directorio.exists()) {
            directorio.mkdirs();
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_TURNOS))) {
            turnos = (Queue<TurnoDTO>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            turnos = new LinkedList<>();
            guardarDatos();
        }
    }

    private void guardarDatos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_TURNOS))) {
            oos.writeObject(turnos);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean crear(TurnoDTO objeto) {
        turnos.offer(objeto);
        guardarDatos();
        return true;
    }

    @Override
    public TurnoDTO leer(String id) {
        for (TurnoDTO turno : turnos) {
            if (turno.getNumero().toString().equals(id)) {
                return turno;
            }
        }
        return null;
    }

    @Override
    public boolean actualizar(TurnoDTO objeto) {
        List<TurnoDTO> tempList = new ArrayList<>(turnos);
        for (int i = 0; i < tempList.size(); i++) {
            if (tempList.get(i).getNumero().equals(objeto.getNumero())) {
                tempList.set(i, objeto);
                turnos = new LinkedList<>(tempList);
                guardarDatos();
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean eliminar(String id) {
        TurnoDTO turnoToRemove = leer(id);
        if (turnoToRemove != null) {
            turnos.remove(turnoToRemove);
            guardarDatos();
            return true;
        }
        return false;
    }

    @Override
    public List<TurnoDTO> listarTodos() {
        return new ArrayList<>(turnos);
    }

    public void guardarTurnos(ArrayList<TurnoDTO> nuevosTurnos) {
        turnos = new LinkedList<>(nuevosTurnos);
        guardarDatos();
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setFechaAtencion(LocalDateTime fechaAtencion) {
        this.fechaAtencion = fechaAtencion;
    }

    public int getNumero() {
        return numero;
    }

    public String getDocumentoPaciente() {
        return documentoPaciente;
    }

    public String getEstado() {
        return estado;
    }

	@Override
	public boolean crear(Object objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean actualizar(Object objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean crear(MedicamentoDTO objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean actualizar(MedicamentoDTO objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	public void guardarTurnos(Object nuevosTurnos) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean crear(UsuarioDTO objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean actualizar(UsuarioDTO objeto) {
		// TODO Auto-generated method stub
		return false;
	}
}