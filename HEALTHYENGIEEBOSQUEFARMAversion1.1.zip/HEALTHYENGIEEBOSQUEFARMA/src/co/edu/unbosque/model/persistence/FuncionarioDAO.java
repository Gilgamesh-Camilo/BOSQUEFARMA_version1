package co.edu.unbosque.model.persistence;

import java.util.ArrayList;

public class FuncionarioDAO extends UsuarioDAO {
    private static final String ARCHIVO_FUNCIONARIOS = "data/funcionarios.dat";
    private ArrayList<FuncionarioDTO> funcionarios;

    public FuncionarioDAO() {
        funcionarios = new ArrayList<>();
        cargarDatos();
    }
}