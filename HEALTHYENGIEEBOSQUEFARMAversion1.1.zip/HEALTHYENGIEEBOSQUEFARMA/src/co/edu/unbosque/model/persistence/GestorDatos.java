package co.edu.unbosque.model.persistence;

import java.io.*;
import java.util.*;
import co.edu.unbosque.model.*;

public class GestorDatos<Usuario> {
    private final String RUTA_BASE;

    public GestorDatos() {
        String userHome = System.getProperty("user.home");
        RUTA_BASE = userHome + File.separator + "Desktop" + File.separator + "bosquefarma" + File.separator;
        inicializarDirectorios();
    }

    private void inicializarDirectorios() {
        File dirPrincipal = new File(RUTA_BASE);
        if (!dirPrincipal.exists()) {
            dirPrincipal.mkdirs();
        }
    }

    private String getRutaArchivo(String tipo) {
        return RUTA_BASE + tipo + ".dat";
    }

    public void guardarUsuarios(ArrayList<UsuarioDAO> usuarios) {
        guardarObjeto(getRutaArchivo("usuarios"), usuarios);
    }

    public ArrayList<UsuarioDAO> cargarUsuarios() {
        ArrayList<Usuario> resultado = (ArrayList<Usuario>) cargarObjeto(getRutaArchivo("usuarios"));
        return resultado != null ? (ArrayList<UsuarioDAO>) resultado : new ArrayList<>();
    }

    public void guardarFuncionarios(ArrayList<FuncionarioDAO> funcionarios) {
        guardarObjeto(getRutaArchivo("funcionarios"), funcionarios);
    }

    public <Funcionario> ArrayList<FuncionarioDAO> cargarFuncionarios() {
        ArrayList<Funcionario> resultado = (ArrayList<Funcionario>) cargarObjeto(getRutaArchivo("funcionarios"));
        return resultado != null ? (ArrayList<FuncionarioDAO>) resultado : new ArrayList<>();
    }

    // Métodos similares para turnos, inventario, etc.

    private void guardarObjeto(String rutaArchivo, Object objeto) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(rutaArchivo))) {
            oos.writeObject(objeto);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private Object cargarObjeto(String rutaArchivo) {
        File archivo = new File(rutaArchivo);
        if (!archivo.exists()) {
            return null;
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(archivo))) {
            return ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return null;
        }
    }

}