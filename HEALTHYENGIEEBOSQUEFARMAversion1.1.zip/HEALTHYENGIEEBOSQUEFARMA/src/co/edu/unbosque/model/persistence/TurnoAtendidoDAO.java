package co.edu.unbosque.model.persistence;

import java.io.*;
import java.util.HashMap;
import java.util.Map;

public class TurnoAtendidoDAO {
    private static final String ARCHIVO_TURNOS_ATENDIDOS = "data/turnos_atendidos.dat";
    private Map<Integer, TurnoAtendidoDTO> turnosAtendidos;

    public TurnoAtendidoDAO() {
        turnosAtendidos = new HashMap<>();
        cargarDatos();
    }

    private void cargarDatos() {
        File directorio = new File("data");
        if (!directorio.exists()) {
            directorio.mkdirs();
        }

        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_TURNOS_ATENDIDOS))) {
            turnosAtendidos = (Map<Integer, TurnoAtendidoDTO>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            turnosAtendidos = new HashMap<>();
            guardarDatos();
        }
    }

    private void guardarDatos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_TURNOS_ATENDIDOS))) {
            oos.writeObject(turnosAtendidos);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public Map<Integer, TurnoAtendidoDTO> obtenerTodos() {
        return new HashMap<>(turnosAtendidos);
    }

    public void crear(TurnoAtendidoDTO turnoAtendido) {
        turnosAtendidos.put(turnoAtendido.getNumero(), turnoAtendido);
        guardarDatos();
    }
}
