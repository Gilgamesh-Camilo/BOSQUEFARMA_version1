package co.edu.unbosque.model.persistence;

import java.io.Serializable;

public class MedicamentoDTO implements Serializable {
    private static final long serialVersionUID = 1L;
    private String codigo;
    private String nombre;
    private int cantidad;
    private double precio;
    private String laboratorio;

    public MedicamentoDTO(String codigo, String nombre, int cantidad, double precio, String laboratorio) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.precio = precio;
        this.laboratorio = laboratorio;
    }

    // Getters y Setters
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    
    public int getCantidad() { return cantidad; }
    public void setCantidad(int cantidad) { this.cantidad = cantidad; }
    
    public double getPrecio() { return precio; }
    public void setPrecio(double precio) { this.precio = precio; }
    
    public String getLaboratorio() { return laboratorio; }
    public void setLaboratorio(String laboratorio) { this.laboratorio = laboratorio; }
}
