package co.edu.unbosque.model.persistence;

import java.io.Serializable;
import java.time.LocalDateTime;

public class TurnoAtendidoDTO implements Serializable {
	
    private static final long serialVersionUID = 1L;
    private int idTurno;
    private LocalDateTime fechaHora;
    private FuncionarioDTO funcionario;

    public TurnoAtendidoDTO(int idTurno, LocalDateTime fechaHora, FuncionarioDTO funcionario) {
        this.idTurno = idTurno;
        this.fechaHora = fechaHora;
        this.funcionario = funcionario;
    }

    // Getters y Setters
    public int getIdTurno() { return idTurno; }
    public void setIdTurno(int idTurno) { this.idTurno = idTurno; }
    public LocalDateTime getFechaHora() { return fechaHora; }
    public void setFechaHora(LocalDateTime fechaHora) { this.fechaHora = fechaHora; }
    public FuncionarioDTO getFuncionario() { return funcionario; }
    public void setFuncionario(FuncionarioDTO funcionario) { this.funcionario = funcionario; }

	public Integer getNumero() {
		// TODO Auto-generated method stub
		return null;
	}
}