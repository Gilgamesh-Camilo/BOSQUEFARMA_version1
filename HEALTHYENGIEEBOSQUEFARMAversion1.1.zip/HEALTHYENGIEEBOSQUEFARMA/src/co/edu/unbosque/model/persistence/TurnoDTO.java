package co.edu.unbosque.model.persistence;

import java.io.Serializable;
import java.time.LocalDateTime;

public class TurnoDTO implements Serializable {
	
    private static final long serialVersionUID = 1L;
    private int numero;
    private String documentoPaciente;
    private LocalDateTime fechaGeneracion;
    private LocalDateTime fechaAtencion;
    private String estado;

    public TurnoDTO(int numero, String documentoPaciente) {
        this.numero = numero;
        this.documentoPaciente = documentoPaciente;
        this.fechaGeneracion = LocalDateTime.now();
        this.estado = "Por atender";
    }

    // Getters y Setters
    public int getNumero() { return numero; }
    public void setNumero(int numero) { this.numero = numero; }
    public String getDocumentoPaciente() { return documentoPaciente; }
    public void setDocumentoPaciente(String documentoPaciente) { this.documentoPaciente = documentoPaciente; }
    public LocalDateTime getFechaGeneracion() { return fechaGeneracion; }
    public void setFechaGeneracion(LocalDateTime fechaGeneracion) { this.fechaGeneracion = fechaGeneracion; }
    public LocalDateTime getFechaAtencion() { return fechaAtencion; }
    public void setFechaAtencion(LocalDateTime fechaAtencion) { this.fechaAtencion = fechaAtencion; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}