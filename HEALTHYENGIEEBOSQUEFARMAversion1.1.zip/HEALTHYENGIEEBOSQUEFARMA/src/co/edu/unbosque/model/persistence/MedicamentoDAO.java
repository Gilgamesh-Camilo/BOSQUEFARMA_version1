package co.edu.unbosque.model.persistence;

import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class MedicamentoDAO implements IDAO {
    private static final String ARCHIVO_MEDICAMENTOS = "data/medicamentos.dat";
    private HashMap<String, MedicamentoDTO> medicamentos;

    public MedicamentoDAO() {
        medicamentos = new HashMap<>();
        cargarDatos();
    }

    private void cargarDatos() {
        File directorio = new File("data");
        if (!directorio.exists()) {
            directorio.mkdirs();
        }
        
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_MEDICAMENTOS))) {
            medicamentos = (HashMap<String, MedicamentoDTO>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            medicamentos = new HashMap<>();
            guardarDatos(); // Create empty file if it doesn't exist
        }
    }

    private void guardarDatos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_MEDICAMENTOS))) {
            oos.writeObject(medicamentos);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean crear(MedicamentoDTO objeto) {
        if (medicamentos.containsKey(objeto.getCodigo())) {
            return false;
        }
        medicamentos.put(objeto.getCodigo(), objeto);
        guardarDatos();
        return true;
    }

    @Override
    public MedicamentoDTO leer(String id) {
        return medicamentos.get(id);
    }

    @Override
    public boolean actualizar(MedicamentoDTO objeto) {
        if (!medicamentos.containsKey(objeto.getCodigo())) {
            return false;
        }
        medicamentos.put(objeto.getCodigo(), objeto);
        guardarDatos();
        return true;
    }

    @Override
    public boolean eliminar(String id) {
        if (!medicamentos.containsKey(id)) {
            return false;
        }
        medicamentos.remove(id);
        guardarDatos();
        return true;
    }

    @Override
    public List<MedicamentoDTO> listarTodos() {
        return new ArrayList<>(medicamentos.values());
    }

    public Map<String, MedicamentoDTO> obtenerTodos() {
        return new HashMap<>(medicamentos);
    }

	@Override
	public boolean crear(Object objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean actualizar(Object objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean crear(TurnoDTO objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean actualizar(TurnoDTO objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean crear(UsuarioDTO objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean actualizar(UsuarioDTO objeto) {
		// TODO Auto-generated method stub
		return false;
	}
}
