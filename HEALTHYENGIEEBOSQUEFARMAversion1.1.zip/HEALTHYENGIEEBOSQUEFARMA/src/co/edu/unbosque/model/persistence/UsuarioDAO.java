package co.edu.unbosque.model.persistence;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO implements IDAO{

    private static final String ARCHIVO_USUARIOS = "usuarios.dat";
    private ArrayList<UsuarioDTO> usuarios;
    
    public UsuarioDAO() {
        usuarios = new ArrayList<>();
        cargarDatos();
    }
    
    protected void cargarDatos() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(ARCHIVO_USUARIOS))) {
            usuarios = (ArrayList<UsuarioDTO>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            usuarios = new ArrayList<>();
        }
    }
    
    private void guardarDatos() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(ARCHIVO_USUARIOS))) {
            oos.writeObject(usuarios);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

	@Override
	public boolean crear(UsuarioDTO objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public UsuarioDTO leer(String id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean actualizar(UsuarioDTO objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean eliminar(String id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<UsuarioDTO> listarTodos() {
		// TODO Auto-generated method stub
		return null;
	}

	public Object getCedula() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean crear(MedicamentoDTO objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean actualizar(MedicamentoDTO objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean crear(TurnoDTO objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean actualizar(TurnoDTO objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean crear(Object objeto) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean actualizar(Object objeto) {
		// TODO Auto-generated method stub
		return false;
	}
}